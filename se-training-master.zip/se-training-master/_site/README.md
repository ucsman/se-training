
# SE Training Document

This Repo contains all the codes created for this training.  The lab guide can be found at NGDC-West jive.
https://cisco.jiveon.com/groups/ngdc-west

# Topics Covered
## Gitlab
## NXOS Ansible
## Sandbox
## NXAPI (CLI)
## REST (object based)
## Nxtoolkit
## Python
