
#To show version

from cli import *
clip('show version


#configing interface
from cli import *
cli('configure terminal ;interface loopback 231 ;ip address 10.10.10.1/24 ;shutdown')

10.114.215.206
telnet 10.114.217.24:2311
